<template>
  <div id="app">
    <Home></Home>
  </div>
</template>

<script>
import Home from "@/views/Home/index.vue";

export default {
  name: 'App',
  components: {Home},

}
</script>

<style scoped>
#app {
  user-select: none;
}
</style>
