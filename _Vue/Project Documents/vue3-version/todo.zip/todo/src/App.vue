<template>
  <div class="todo-container">
    <div class="todo-wrap">
      <Header
          :todos="todos"
          :addTodo="addTodo"
      ></Header>
      <Main
          :todos="todos"
          :checkTodo="checkTodo"
          :deleteTodo="deleteTodo"
      ></Main>
      <Footer
          :todos="todos"
          :checkAll="checkAll"
          :deleteCheck="deleteCheck"
      ></Footer>
    </div>
  </div>
</template>

<script setup lang="ts">
import Header from '@/components/Header/index.vue'
import Main from '@/components/Main/index.vue'
import Footer from '@/components/Footer/index.vue'
import {ref, watch} from 'vue';

// 定义接口
export interface TodoModel {
  id: number,
  content: string,
  isSel: boolean
}

// 声明类型
export type TodosModel = TodoModel[]


const todos = ref<TodosModel>(JSON.parse(localStorage.getItem('TODOS') as string) || [
  {id: 1001, content: '读书', isSel: true},
  {id: 1002, content: '看报', isSel: true},
  {id: 1003, content: '学习', isSel: true},
])

watch(todos, (nval, oval) => {
  localStorage.setItem("TODOS", JSON.stringify(nval))
}, {deep: true})

// 添加Todo
const addTodo = (todo: TodoModel) => {
  todos.value.push(todo)
}

// 选中Todo
const checkTodo = (index: number) => {
  todos.value[index].isSel = !todos.value[index].isSel
}

// 删除Todo
const deleteTodo = (index: number) => {
  todos.value.splice(index, 1)
}

// 全选交互
const checkAll = (bool: boolean) => {
  todos.value.forEach(todo => todo.isSel = bool)
}

// 清除选中
const deleteCheck = () => {
  todos.value = todos.value.filter(todo => !todo.isSel)
}


</script>

<style scoped>
/*app*/
.todo-container {
  width: 600px;
  margin: 0 auto;
}

.todo-container .todo-wrap {
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}
</style>
