<template>
  <div class="todo-footer">
    <label>
      <input type="checkbox" v-model="isCheckAll"/>
    </label>
    <span>
      <span>已完成{{ checkCount }}</span> / 全部{{ todos.length }}
    </span>
    <button class="btn btn-danger" @click="deleteCheck">清除已完成任务</button>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import type { TodoModel, TodosModel } from '../../App.vue';

// Tip: 定义 defineProps 得到的 props 数据类型
interface PropsModel {
  todos: TodosModel,
  checkAll: (bool: boolean) => void,
  deleteCheck: () => void
}


const props = defineProps<PropsModel>();


// 选中个数
const checkCount = computed(() => {
  return props.todos.reduce((prev: number, todo: TodoModel) => {
    // （isSel 为 布尔值）强制转换 Boolean 类型
    return prev + Number(todo.isSel)
  }, 0)
});

// 全选状态
const isCheckAll = computed({
  get() {
    return props.todos.every((todo: TodoModel) => todo.isSel)
  },
  set(val) {
    props.checkAll(val)
  }
});


</script>

<style scoped>
/*footer*/
.todo-footer {
  height: 40px;
  line-height: 40px;
  padding-left: 6px;
  margin-top: 5px;
}

.todo-footer label {
  display: inline-block;
  margin-right: 20px;
  cursor: pointer;
}

.todo-footer label input {
  position: relative;
  top: -1px;
  vertical-align: middle;
  margin-right: 5px;
}

.todo-footer button {
  float: right;
  margin-top: 5px;
}
</style>