// 每个 Vue 应用都是通过 createApp 函数创建一个新的 应用实例：
import { createApp } from 'vue'
import App from './App.vue'

import './assets/main.css'

createApp(App).mount('#app')
