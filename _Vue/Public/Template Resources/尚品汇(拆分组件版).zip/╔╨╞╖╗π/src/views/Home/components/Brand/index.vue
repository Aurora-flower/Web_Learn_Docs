<template>
  <div class="brand">
    <div class="py-container">
      <ul class="brand-list">
        <li class="brand-item">
          <img src="@/views/Home/images/brand_21.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_03.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_05.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_07.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_09.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_11.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_13.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_15.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_17.png"  alt=""/>
        </li>
        <li class="brand-item">
          <img src="@/views/Home/images/brand_19.png"  alt=""/>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Brand",
}
</script>

<style lang="less" scoped>

</style>