<template>
  <div class="copyright">
    <ul>
      <li>关于我们</li>
      <li>联系我们</li>
      <li>联系客服</li>
      <li>商家入驻</li>
      <li>营销中心</li>
      <li>手机尚品汇</li>
      <li>销售联盟</li>
      <li>尚品汇社区</li>
    </ul>
    <div class="address">地址：北京市昌平区宏福科技园综合楼6层</div>
    <div class="beian">京ICP备19006430号
    </div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Copyright",

}
</script>

<style lang="less" scoped>
.copyright{
  width: 1200px;
  margin: 0 auto;
  text-align: center;
  line-height: 24px;
  ul{
    li{
      display: inline-block;
      border-right: 1px solid #e4e4e4;
      padding: 0 20px;
      margin: 15px 0;
    }
  }
}
</style>