<template>
  <div class="outer">
    <Header></Header>
    <TypeNav></TypeNav>
    <ListContainer></ListContainer>
    <Recommend></Recommend>
    <Rank></Rank>
    <Like></Like>
    <Floor></Floor>
    <Floor></Floor>
    <Footer></Footer>
  </div>
</template>

<script>

import ListContainer from "@/views/Home/components/ListContainer/index.vue";
import Rank from "@/views/Home/components/Rank/index.vue";
import Recommend from "@/views/Home/components/Recommend/index.vue";
import Like from "@/views/Home/components/Like/index.vue";
import Floor from "@/views/Home/components/Floor/index.vue";

export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Home",
  components: {Floor, Like, Recommend, Rank, ListContainer},
}
</script>

<style scoped>

</style>