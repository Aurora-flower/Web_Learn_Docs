<template>
  <div class="outer">
    <!-- 窗口侧边栏 -->
    <div class="toolbar toolbar-wrap">
      <div class="content"></div>
      <div class="but list"></div>
      <div class="toolist">
        <div class="pull">
          <i class="tab-ico vip"></i>
          <em class="tab-text">商品会员</em>
        </div>
        <div class="pull">
          <i class="tab-ico cart"></i>
          <em class="tab-text">购物车</em>
        </div>
        <div class="pull">
          <i class="tab-ico follow"></i>
          <em class="tab-text">我的关注</em>
        </div>
        <div class="pull">
          <i class="tab-ico history"></i>
          <em class="tab-text">我的足迹</em>
        </div>
        <div class="pull">
          <i class="tab-ico message"></i>
          <em class="tab-text">我的消息</em>
        </div>
        <div class="pull">
          <i class="tab-ico jimi"></i>
          <em class="tab-text">咨询</em>
        </div>
      </div>
      <div class="back pull">
        <i class="tab-ico top"></i>
        <em class="tab-text">顶部</em>
      </div>
    </div>

    <!-- 商品分类导航 -->
    <TypeNav></TypeNav>

    <!--list-content-->
    <div class="main">
      <div class="py-container">
        <!--bread-->
        <div class="bread">
          <ul class="fl sui-breadcrumb">
            <li>
              <a href="#">全部结果</a>
            </li>
          </ul>
          <ul class="fl sui-tag">
            <li class="with-x">手机</li>
            <li class="with-x">iphone<i>×</i></li>
            <li class="with-x">华为<i>×</i></li>
            <li class="with-x">OPPO<i>×</i></li>
          </ul>
        </div>
        <!--selector-->
        <div class="clearfix selector">
          <div class="type-wrap logo">
            <div class="fl key brand">品牌</div>
            <div class="value logos">
              <ul class="logo-list">
                <li>索尼（SONY）</li>
                <li>TCL</li>
                <li>长虹（CHANGHONG）</li>
                <li>飞利浦（PHILIPS）</li>
                <li>风行电视</li>
                <li><img src="./images/phone06.png" alt=""/></li>
                <li><img src="./images/phone07.png" alt=""/></li>
                <li><img src="./images/phone08.png" alt=""/></li>
                <li><img src="./images/phone09.png" alt=""/></li>
                <li><img src="./images/phone10.png" alt=""/></li>
                <li><img src="./images/phone11.png" alt=""/></li>
                <li><img src="./images/phone12.png" alt=""/></li>
                <li><img src="./images/phone12.png" alt=""/></li>
                <li><img src="./images/phone14.png" alt=""/></li>
                <li><img src="./images/phone01.png" alt=""/></li>
                <li><img src="./images/phone06.png" alt=""/></li>
                <li><img src="./images/phone07.png" alt=""/></li>
                <li><img src="./images/phone02.png" alt=""/></li>
              </ul>
            </div>
          </div>
          <div class="type-wrap">
            <div class="fl key">网络制式</div>
            <div class="fl value">
              <ul class="type-list">
                <li>
                  <a>GSM（移动/联通2G）</a>
                </li>
                <li>
                  <a>电信2G</a>
                </li>
                <li>
                  <a>电信3G</a>
                </li>
                <li>
                  <a>移动3G</a>
                </li>
                <li>
                  <a>联通3G</a>
                </li>
                <li>
                  <a>联通4G</a>
                </li>
                <li>
                  <a>电信3G</a>
                </li>
                <li>
                  <a>移动3G</a>
                </li>
                <li>
                  <a>联通3G</a>
                </li>
                <li>
                  <a>联通4G</a>
                </li>
              </ul>
            </div>
            <div class="fl ext"></div>
          </div>
          <div class="type-wrap">
            <div class="fl key">显示屏尺寸</div>
            <div class="fl value">
              <ul class="type-list">
                <li>
                  <a>4.0-4.9英寸</a>
                </li>
                <li>
                  <a>4.0-4.9英寸</a>
                </li>
              </ul>
            </div>
            <div class="fl ext"></div>
          </div>
          <div class="type-wrap">
            <div class="fl key">摄像头像素</div>
            <div class="fl value">
              <ul class="type-list">
                <li>
                  <a>1200万以上</a>
                </li>
                <li>
                  <a>800-1199万</a>
                </li>
                <li>
                  <a>1200-1599万</a>
                </li>
                <li>
                  <a>1600万以上</a>
                </li>
                <li>
                  <a>无摄像头</a>
                </li>
              </ul>
            </div>
            <div class="fl ext"></div>
          </div>
          <div class="type-wrap">
            <div class="fl key">价格</div>
            <div class="fl value">
              <ul class="type-list">
                <li>
                  <a>0-500元</a>
                </li>
                <li>
                  <a>500-1000元</a>
                </li>
                <li>
                  <a>1000-1500元</a>
                </li>
                <li>
                  <a>1500-2000元</a>
                </li>
                <li>
                  <a>2000-3000元 </a>
                </li>
                <li>
                  <a>3000元以上</a>
                </li>
              </ul>
            </div>
            <div class="fl ext">
            </div>
          </div>
          <div class="type-wrap">
            <div class="fl key">更多筛选项</div>
            <div class="fl value">
              <ul class="type-list">
                <li>
                  <a>特点</a>
                </li>
                <li>
                  <a>系统</a>
                </li>
                <li>
                  <a>手机内存 </a>
                </li>
                <li>
                  <a>单卡双卡</a>
                </li>
                <li>
                  <a>其他</a>
                </li>
              </ul>
            </div>
            <div class="fl ext">
            </div>
          </div>
        </div>
        <!--details-->
        <div class="details clearfix">
          <div class="sui-navbar">
            <div class="navbar-inner filter">
              <ul class="sui-nav">
                <li class="active">
                  <a href="#">综合</a>
                </li>
                <li>
                  <a href="#">销量</a>
                </li>
                <li>
                  <a href="#">新品</a>
                </li>
                <li>
                  <a href="#">评价</a>
                </li>
                <li>
                  <a href="#">价格⬆</a>
                </li>
                <li>
                  <a href="#">价格⬇</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="goods-list">
            <ul class="yui3-g">
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <a href="#"  target="_blank">
                      <img src="./images/mobile01.png"  alt=""/>
                    </a>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile02.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile03.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile04.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile05.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile06.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile01.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile02.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile03.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-5">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/mobile04.png"  alt=""/>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>6088.00</i>
                    </strong>
                  </div>
                  <div class="attr">
                    <a target="_blank" href="#"  title="促销信息，下单即赠送三个月CIBN视频会员卡！【小米电视新品4A 58 火爆预约中】">Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)Apple苹果iPhone 6s (A1699)</a>
                  </div>
                  <div class="commit">
                    <i class="command">已有<span>2000</span>人评价</i>
                  </div>
                  <div class="operate">
                    <a href="#" target="_blank" class="sui-btn btn-bordered btn-danger">加入购物车</a>
                    <a href="javascript:void(0);" class="sui-btn btn-bordered">收藏</a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="fr page">
            <div class="sui-pagination clearfix">
              <ul>
                <li class="prev disabled">
                  <a href="#">«上一页</a>
                </li>
                <li class="active">
                  <a href="#">1</a>
                </li>
                <li>
                  <a href="#">2</a>
                </li>
                <li>
                  <a href="#">3</a>
                </li>
                <li>
                  <a href="#">4</a>
                </li>
                <li>
                  <a href="#">5</a>
                </li>
                <li class="dotted"><span>...</span></li>
                <li class="next">
                  <a href="#">下一页»</a>
                </li>
              </ul>
              <div><span>共10页&nbsp;</span></div>
            </div>
          </div>
        </div>
        <!--hotsale-->
        <div class="clearfix hot-sale">
          <h4 class="title">热卖商品</h4>
          <div class="hot-list">
            <ul class="yui3-g">
              <li class="yui3-u-1-4">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/like_01.png"  alt=""/>
                  </div>
                  <div class="attr">
                    <em>Apple苹果iPhone 6s (A1699)</em>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>4088.00</i>
                    </strong>
                  </div>
                  <div class="commit">
                    <i class="command">已有700人评价</i>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-4">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/like_03.png"  alt=""/>
                  </div>
                  <div class="attr">
                    <em>金属A面，360°翻转，APP下单省300！</em>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>4088.00</i>
                    </strong>
                  </div>
                  <div class="commit">
                    <i class="command">已有700人评价</i>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-4">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/like_04.png"  alt=""/>
                  </div>
                  <div class="attr">
                    <em>256SSD商务大咖，完爆职场，APP下单立减200</em>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>4068.00</i>
                    </strong>
                  </div>
                  <div class="commit">
                    <i class="command">已有20人评价</i>
                  </div>
                </div>
              </li>
              <li class="yui3-u-1-4">
                <div class="list-wrap">
                  <div class="p-img">
                    <img src="./images/like_02.png"  alt=""/>
                  </div>
                  <div class="attr">
                    <em>Apple苹果iPhone 6s (A1699)</em>
                  </div>
                  <div class="price">
                    <strong>
                      <em>¥</em>
                      <i>4088.00</i>
                    </strong>
                  </div>
                  <div class="commit">
                    <i class="command">已有700人评价</i>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部 -->
    <div class="footer">
      <div class="footer-container">
        <div class="footerList">
          <div class="footerItem">
            <h4>购物指南</h4>
            <ul class="footerItemCon">
              <li>购物流程</li>
              <li>会员介绍</li>
              <li>生活旅行/团购</li>
              <li>常见问题</li>
              <li>购物指南</li>
            </ul>

          </div>
          <div class="footerItem">
            <h4>配送方式</h4>
            <ul class="footerItemCon">
              <li>上门自提</li>
              <li>211限时达</li>
              <li>配送服务查询</li>
              <li>配送费收取标准</li>
              <li>海外配送</li>
            </ul>
          </div>
          <div class="footerItem">
            <h4>支付方式</h4>
            <ul class="footerItemCon">
              <li>货到付款</li>
              <li>在线支付</li>
              <li>分期付款</li>
              <li>邮局汇款</li>
              <li>公司转账</li>
            </ul>
          </div>
          <div class="footerItem">
            <h4>售后服务</h4>
            <ul class="footerItemCon">
              <li>售后政策</li>
              <li>价格保护</li>
              <li>退款说明</li>
              <li>返修/退换货</li>
              <li>取消订单</li>
            </ul>
          </div>
          <div class="footerItem">
            <h4>特色服务</h4>
            <ul class="footerItemCon">
              <li>夺宝岛</li>
              <li>DIY装机</li>
              <li>延保服务</li>
              <li>尚品汇E卡</li>
              <li>尚品汇通信</li>
            </ul>
          </div>
          <div class="footerItem">
            <h4>帮助中心</h4>
            <img src="@/assets/wx_cz.jpg" alt="">
          </div>
        </div>
        <Copyright></Copyright>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Search",
}
</script>

<style lang="less" scoped>
.toolbar{
  position: fixed;
  z-index: 999;
  width: 300px;
  height: 100%;
  background-color: #7a6e6e;
  transition: right .3s ease-in-out 0s;
  &.toolbar-out{
    top: 0;
    right: 0;
  }
  &.toolbar-wrap{
    top: 0;
    right: -294px;
  }
  .content{
    position: relative;
    left: 6px;
    width: 294px;
    background-color: bisque;
    height: 100%;
    z-index: 99;
  }
  .but{
    width: 35px;
    height: 35px;
    line-height: 35px;
    text-align: center;
    margin-bottom: 1px;
    cursor: pointer;
    background-color: #7a6e6e;
    border-radius: 3px 0 0 3px;
    position: absolute;
    top: 0;
    /*right: -6px;*/
    left: -29px;
    &.list{
      background-image: url(@/views/Search/images/list.png);
      background-repeat: no-repeat;
      background-size: cover;
    }
    &.pull-wrap{
      background-image: url(@/views/Search/images/cross.png);
      background-repeat: no-repeat;
      background-size: cover;
    }
  }
  .toolist{
    position: absolute;
    top: 50%;
    left: -29px;
    width: 35px;
    margin-top: -80px;
    /*background-color: cadetblue;*/
    .pull{
      position: relative;
      width: 35px;
      height: 35px;
      line-height: 35px;
      text-align: center;
      margin-bottom: 1px;
      cursor: pointer;
      background-color: #7a6e6e;
      border-radius: 3px 0 0 3px;
      z-index: 66;
      .vip{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -88px -175px;
      }
      .cart{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -50px 0;
      }
      .follow{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -50px -50px;
      }
      .history{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -50px -100px;
      }
      .message{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -190px -150px;
      }
      .jimi{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -50px -150px;
      }
      .top{
        background-image: url(@/views/Search/images/toolbars.png);
        background-position: -50px -250px;
      }

      .tab-text {
        width: 62px;
        height: 35px;
        line-height: 35px;
        color: #fff;
        text-align: center;
        font-family: 微软雅黑,serif;
        position: absolute;
        /*position: relative;*/
        z-index: 1;
        left: 35px;
        top: 0;
        background-color: #7a6e6e;
        border-radius: 3px 0 0 3px;
        font-style: normal;
        -webkit-transition: left .3s ease-in-out .1s;
        transition: left .3s ease-in-out .1s;
      }
      .tab-ico{
        display: inline-block;
        position: relative;
        /*background-image: url(img/toolbars.png);*/
        background-color:#7a6e6e ;
        border-radius: 3px 0 0 3px;
        z-index: 2;
        width: 35px;
        height: 35px;
      }
    }
  }

  &>.pull{
    position: relative;
    width: 35px;
    height: 35px;
    line-height: 35px;
    text-align: center;
    margin-bottom: 1px;
    cursor: pointer;
    background-color: #7a6e6e;
    border-radius: 3px 0 0 3px;
    z-index: 66;
    .tab-ico{
      display: inline-block;
      position: relative;
      /*background-image: url(img/toolbars.png);*/
      background-color:#7a6e6e ;
      border-radius: 3px 0 0 3px;
      z-index: 2;
      width: 35px;
      height: 35px;
    }
    .top{
      background-image: url(@/views/Search/images/toolbars.png);
      background-position: -50px -250px;
    }

    .tab-text {
      width: 62px;
      height: 35px;
      line-height: 35px;
      color: #fff;
      text-align: center;
      font-family: 微软雅黑,serif;
      position: absolute;
      /*position: relative;*/
      z-index: 1;
      left: 35px;
      top: 0;
      background-color: #7a6e6e;
      border-radius: 3px 0 0 3px;
      font-style: normal;
      -webkit-transition: left .3s ease-in-out .1s;
      transition: left .3s ease-in-out .1s;
    }
  }
  &>.back{
    position: absolute;
    bottom: 0;
    /*right: -6px;*/
    left: -29px;
    display: inline-block;
    background-image: url(@/views/Search/images/toolbars.png);

  }
}

.main{
  margin: 10px 0;
  .py-container{
    width: 1200px;
    margin: 0 auto;
    .bread{
      margin-bottom: 5px;
      overflow: hidden;
      .sui-breadcrumb{
        padding: 3px 15px;
        margin: 0;
        font-weight: 400;
        border-radius: 3px;
        float:left;
        li{
          display: inline-block;
          line-height: 18px;
          a{
            color: #666;
            text-decoration: none;
            &:hover{
              color: #4cb9fc;
            }
          }
        }
      }
      .sui-tag{
        margin-top: -5px;
        list-style: none;
        font-size: 0;
        line-height: 0;
        padding: 5px 0 0;
        margin-bottom: 18px;
        float: left;
        .with-x{
          font-size: 12px;
          margin: 0 5px 5px 0;
          display: inline-block;
          overflow: hidden;
          color: #000;
          background: #f7f7f7;
          padding: 0 7px;
          height: 20px;
          line-height: 20px;
          border: 1px solid #dedede;
          white-space: nowrap;
          transition:color 400ms;
          cursor: pointer;
          i{
            margin-left: 10px;
            cursor: pointer;
            font: 400 14px tahoma;
            display: inline-block;
            height: 100%;
            vertical-align: middle;
          }
          &:hover{
            color: #28a3ef;
          }
        }
      }
    }
    .selector{
      border: 1px solid #ddd;
      margin-bottom: 5px;
      overflow: hidden;
      .logo{
        border-top: 0;
        margin: 0;
        position: relative;
        overflow: hidden;
        .key{
          padding-bottom: 87px!important;
        }
      }
      .type-wrap{
        margin: 0;
        position: relative;
        border-top: 1px solid #ddd;
        overflow:hidden;
        .key{
          width: 100px;
          background: #f1f1f1;
          line-height: 26px;
          text-align: right;
          padding: 10px 10px 0 15px;
          float:left;
        }
        .value{
          overflow: hidden;
          color: #333;
          margin-left: 120px;
          padding: 10px 90px 0 15px;

          .logo-list{
            li{
              float: left;
              border: 1px solid #e4e4e4;
              margin: -1px -1px 0 0;
              width: 105px;
              height: 52px;
              text-align: center;
              line-height: 52px;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              font-weight: 700;
              color: #e1251b;
              font-style: italic;
              font-size: 14px;
              img{
                max-width: 100%;
                vertical-align: middle;
              }
            }
          }
          .type-list{
            li{
              float: left;
              display: block;
              margin-right: 30px;
              line-height: 26px;
              a{
                text-decoration: none;
                color: #666;
              }
            }
          }
        }
        .ext{
          position: absolute;
          top: 10px;
          right: 10px;
          .sui-btn{
            display: inline-block;
            box-sizing: border-box;
            margin-bottom: 0;
            font-size: 12px;
            line-height: 18px;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            background: #fff;
            border: 1px solid #d5d5d5;
          }
          a{
            color: #666;
          }
        }
      }
    }
    .details{
      margin-bottom: 5px;
      .sui-navbar{
        overflow: visible;
        margin-bottom: 0;
        .filter{
          min-height: 40px;
          padding-right: 20px;
          background: #fbfbfb;
          border: 1px solid #e2e2e2;
          padding-left: 0;
          border-radius: 0;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
          .sui-nav{
            position: relative;
            left: 0;
            display: block;
            float: left;
            margin: 0 10px 0 0;
            li{
              float: left;
              line-height: 18px;
              a{
                display: block;
                cursor: pointer;
                padding: 11px 15px;
                color: #777;
                text-decoration: none;
              }
              &.active{
                a{
                  background: #e1251b;
                  color: #fff;
                }
              }
            }
          }
        }
      }
      .goods-list{
        margin: 20px 0;
        ul{
          display:flex;
          flex-wrap:wrap;
          li{
            height: 100%;
            width: 20%;
            margin-top: 10px;
            line-height: 28px;
            .list-wrap{
              .p-img{
                padding-left: 15px;
                width: 215px;
                height: 255px;
                a{
                  color: #666;
                  img{
                    max-width: 100%;
                    height: auto;
                    vertical-align: middle;
                  }
                }
              }
              .price{
                padding-left: 15px;
                font-size: 18px;
                color: #c81623;
                strong{
                  font-weight: 700;
                  i{
                    margin-left: -5px;
                  }
                }
              }
              .attr{
                padding-left: 15px;
                width: 85%;
                overflow: hidden;
                margin-bottom: 8px;
                min-height: 38px;
                cursor: pointer;
                line-height: 1.8;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                a{
                  color: #333;
                  text-decoration: none;
                }
              }
              .commit{
                padding-left: 15px;
                height: 22px;
                font-size: 13px;
                color: #a7a7a7;
                span{
                  font-weight: 700;
                  color: #646fb0;
                }
              }
              .operate{
                padding: 12px 15px;
                .sui-btn{
                  display: inline-block;
                  padding: 2px 14px;
                  box-sizing: border-box;
                  margin-bottom: 0;
                  font-size: 12px;
                  line-height: 18px;
                  text-align: center;
                  vertical-align: middle;
                  cursor: pointer;
                  border-radius: 0;
                  background-color: transparent;
                  margin-right: 15px;
                }
                .btn-bordered{
                  min-width: 85px;
                  background-color: transparent;
                  border: 1px solid #8c8c8c;
                  color: #8c8c8c;
                  &:hover{
                    border: 1px solid #666;
                    color: #fff!important;
                    background-color: #666;
                    text-decoration: none;
                  }
                }
                .btn-danger{
                  border: 1px solid #e1251b;
                  color: #e1251b;
                  &:hover{
                    border: 1px solid #e1251b;
                    background-color: #e1251b;
                    color:white!important;
                    text-decoration: none;
                  }
                }
              }
            }
          }
        }
      }
      .page{
        width: 733px;
        height: 66px;
        overflow: hidden;
        float:right;
        .sui-pagination{
          margin: 18px 0;
          ul{
            margin-left: 0;
            margin-bottom: 0;
            vertical-align: middle;
            width: 490px;
            float: left;
            li{
              line-height: 18px;
              display: inline-block;
              a{
                position: relative;
                float: left;
                line-height: 18px;
                text-decoration: none;
                background-color: #fff;
                border: 1px solid #e0e9ee;
                margin-left: -1px;
                font-size: 14px;
                padding: 9px 18px;
                color: #333;
              }
              &.active{
                a{
                  background-color: #fff;
                  color: #e1251b;
                  border-color: #fff;
                  cursor: default;
                }
              }
              &.prev{
                a{
                  background-color: #fafafa;
                }
              }
              &.disabled{
                a{
                  color: #999;
                  cursor: default;
                }
              }
              &.dotted{
                span{
                  margin-left: -1px;
                  position: relative;
                  float: left;
                  line-height: 18px;
                  text-decoration: none;
                  background-color: #fff;
                  font-size: 14px;
                  border: 0;
                  padding: 9px 18px;
                  color: #333;
                }
              }
              &.next{
                a{
                  background-color: #fafafa;
                }
              }
            }
          }
          div{
            color: #333;
            font-size: 14px;
            float: right;
            width: 241px;
          }
        }
      }
    }
    .hot-sale{
      margin-bottom: 5px;
      border: 1px solid #ddd;
      .title{
        font-weight: 700;
        font-size: 14px;
        line-height: 21px;
        border-bottom: 1px solid #ddd;
        background: #f1f1f1;
        color: #333;
        margin: 0;
        padding: 5px 0 5px 15px;
      }
      .hot-list{
        padding: 15px;
        ul{
          display:flex;
          li{
            width:25%;
            height: 100%;
            .list-wrap{
              .p-img,.price,.attr,.commit{
                padding-left: 15px;
              }
              .p-img{
                img{
                  max-width: 100%;
                  vertical-align: middle;
                  border: 0;
                }
              }
              .attr{
                width: 85%;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
                margin-bottom: 8px;
                min-height: 38px;
                cursor: pointer;
                line-height: 1.8;
              }
              .price{
                font-size: 18px;
                color: #c81623;
                strong{
                  font-weight: 700;
                  i{
                    margin-left: -5px;
                  }
                }
              }
              .commit{
                height:22px;
                font-size: 13px;
                color: #a7a7a7;
              }
            }
          }
        }
      }
    }
  }
}

</style>