<template>
  <ul class="todo-main">
    <Item
      v-for="(todo, index) in todos"
      :key="index"
      :todo="todo"
      :index="index"
      :checkTodo="checkTodo"
      :deleteTodo="deleteTodo"
    ></Item>
  </ul>
</template>

<script setup lang="ts">

import Item from '@/components/Item/index.vue'

// 接收 props 参数
const props = defineProps(['todos', 'checkTodo', 'deleteTodo'])


</script>

<style scoped>

/*main*/
.todo-main {
  margin-left: 0;
  border: 1px solid #ddd;
  border-radius: 2px;
  padding: 0;
}

.todo-empty {
  height: 40px;
  line-height: 40px;
  border: 1px solid #ddd;
  border-radius: 2px;
  padding-left: 5px;
  margin-top: 10px;
}
</style>