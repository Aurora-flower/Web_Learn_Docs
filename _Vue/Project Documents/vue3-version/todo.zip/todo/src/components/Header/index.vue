<template>
  <div class="todo-header">
    <input type="text" placeholder="请输入你的任务名称，按回车键确认"
           v-model="keyword" @keyup.enter="addTodoHandler"/>
  </div>
</template>

<script setup lang="ts">
// 使用 import type 和export type导入和导出的类型只能在类型上下文中使用, 不能作为一个值来使用.
import type {TodoModel, TodosModel} from '../../App.vue'
import {ref} from 'vue';

// defineProps 用来接收 props 参数
const props = defineProps<{
  todos: TodosModel,
  // addTodo: Function,  // 相比较 ts，范围太大
  addTodo: (arg: TodoModel) => void,
}>()


// 表单数据
const keyword = ref('');

const addTodoHandler = () => {
  // trim（）去除字符串首尾空格
  let text = keyword.value.trim();

  // 非空校验
  if (!text) {
    console.log(">>> 输入的内容为空，请重试...");
    keyword.value = '';
    return;
  }

  // 重复校验
  let isRepeat = props.todos.map((todo: TodoModel) => todo.content).includes(text)
  if (isRepeat) {
    console.log(">>> 输入的内容重复，请重试...");
    // 每次存储后，输入框清空
    keyword.value = '';
    return;
  }


  let todo = {
    id: Date.now(),
    content: text,
    isSel: false
  };

  props.addTodo(todo);

  keyword.value = "";

}

</script>

<style scoped>

/*header*/
.todo-header input {
  width: 560px;
  height: 28px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 4px 7px;
}

.todo-header input:focus {
  outline: none;
  border-color: rgba(82, 168, 236, 0.8);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);
}
</style>