import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 全局注册
import Header from "@/components/Header/index.vue";
import TypeNav from "@/components/TypeNav/index.vue";
import Footer from "@/components/Footer/index.vue";
import Copyright from "@/components/Copyright/index.vue";

Vue.component(Header.name, Header);
Vue.component(TypeNav.name, TypeNav);
Vue.component(Footer.name, Footer);
Vue.component(Copyright.name, Copyright);


new Vue({
    render: h => h(App),
}).$mount('#app');

